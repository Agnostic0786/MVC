<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
#ab:link, #ab:visited {
    background-color: #C52D36 ;
    color: white;
    padding: 14px 25px;
    text-align: center; 
    margin-top:15px;
    display: inline-block;
    font-size:16px;
	font-family:"Arial Black", Gadget, sans-serif;
}

#ab:hover, #ab:active {
    background-color:;
	text-decoration:none;
}
u
{
	   padding-bottom:28px;
	 text-decoration: none;
}
u:hover
{
    border-bottom-width:large;
	border-bottom:10px solid #D6545C  ;
}
</style>
</head>
<body>
<div class="container-fluid">
<div class="row" >
<div class="col-sm-12" style="height:60px;background-color:#3E3E42   ">
</div>
</div>
<div class="row" style="box-shadow: 2px 2px #AFAFAF  ;">
<div class="col-sm-4" style="height:90px;background-image: url('i1.png');background-repeat: no-repeat;background-position:center center">
</div>
<div class="col-sm-8" style="height:90px;background-color:#C52D36  ">
<a id="ab" href="Home.php" ><u>Home</u></a>
<a id="ab" href="Aboutus.php" ><u>About Us</u></a>
<a id="ab" href="Ourquality.php" ><u>Our Quality</u></a>
<a id="ab" href="Shop.php" ><u>Shop</u></a>
<a id="ab" href="Blog.php" ><u>Blog</u></a>
<a id="ab" href="Contactus.php" ><u>Contact Us</u>	</a>
</div>
</div>
<div class="row" style="margin-top:2px;">
<div class="col-sm-12" style="height:500px;background-image : url('i2.jpg');background-size :100% 100%;background-repeat:no-repeat">
<div class="col-sm-4">
</div>
<div class="col-sm-4">
<font style="position:fixed; bottom:400px;  text-align: center;font-size:15px;color:#CB4A52;margin-left:6%;font-family:Impact, Charcoal, sans-serif">ENJOY &nbsp;&nbsp;&nbsp;OUR&nbsp;&nbsp;&nbsp; PREMIUM&nbsp;&nbsp;&nbsp; QUALITY</font>
<h1 style="margin-left:-90px;color:#FDFEFE  ;font-size:50px;font-family:Georgia, serif;position:fixed; bottom:250px;text-align: center;">Wholesale Saffron Bulbs<br>
(Crocus Sativus)</h1>
</div>
<div class="col-sm-4">
</div>
</div>
</div>
</div>
</body>
</html>