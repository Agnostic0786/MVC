<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
#ab:link, #ab:visited {
    background-color: #C52D36 ;
    color: white;
    padding: 14px 25px;
    text-align: center; 
    margin-top:15px;
    display: inline-block;
    font-size:16px;
	font-family:"Arial Black", Gadget, sans-serif;
}

#ab:hover, #ab:active {
    background-color:;
	text-decoration:none;
}
u
{
	   padding-bottom:28px;
	 text-decoration: none;
}
u:hover
{
    border-bottom-width:large;
	border-bottom:10px solid #D6545C  ;
}
#b1 {
    background-color: #8CDD44    ; 
    border: none;
    color: white;
    text-align:center;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	position:absolute; 
	top:400px;  
	left : 13px;
	text-align: center;
	height:60px;
	width:110px;
	padding :17px 2px 2px 2px ;
}
#b1:hover
{
	background-color : #89C454  ;
}
#b2
{
	background-color:transparent;
	  border: 2px solid white;
    color: white;
  text-align:center;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	position:absolute; 
	left :50px;
	top :320px;
	text-align: center;
	margin-left:100px;
	height:60px;
	width:230px;
}
#b2:hover
{
	border:2px solid #B2BABB  ;
}
#id1:hover{
	opacity : 0.5;
}
#id2:hover
{
	display : block;
}
#image1:hover
{
     border : 2px solid red;	
}
</style>
</head>
<body>
<?php

?>
<div class="container-fluid">
<div class="row" >
<div class="col-sm-12" style="height:60px;background-color:#3E3E42   ">
<div class="col-sm-3" style="height:60px;" >
<img src="1st.png"></img>
<a href="#"><font style="font-family:Georgia, serif;color:white">Shop Now for US</font></a>
</div>
<div class="col-sm-3" >
<img src="2nd.png"></img>
<a href="#"><font style="font-family:Georgia, serif;color:white">Shop Now For EU countries</font></a>
</div>
<div class="col-sm-3" >
<font style="position:absolute;top:20px;font-family:Georgia, serif;color:white">&#x260F;+31 6162 46 981</font>
</div>
<div class="col-sm-3" >
<a href="#"><font style="position:absolute;top:20px;font-family:Georgia, serif;color:white">Whole Sale Saffron bulbs(Roco Sativus)</font></a>

</div>
</div>
</div>
<div class="row" style="box-shadow: 2px 2px #AFAFAF  ;">
<div class="col-sm-4" style="height:90px;background-image: url('i1.png');background-repeat: no-repeat;background-position:center center">
</div>
<div class="col-sm-8" style="height:90px;background-color:#C52D36  ">
<a id="ab" href="Home.php" ><u>Home</u></a>
<a id="ab" href="Aboutus.php" ><u>About Us</u></a>
<a id="ab" href="Ourquality.php" ><u>Our Quality</u></a>
<a id="ab" href="Shop.php" ><u>Shop</u></a>
<a id="ab" href="Blog.php" ><u>The Saffron Blog</u></a>
<a id="ab" href="Contactus.php" ><u>Contact Us</u>	</a>
</div>
</div>

<div class="row" style="background-color:#F3EAE8;height:150px">
<h1 style="text-align:center;margin-left:70px;font-family:Georgia, serif;font-size:50px">Roco Saffron Shop</h1>
<font color="grey" style="position:absolute;left:490px;margin-left:70px">Order our Premium Quality Saffron Bulbs now!</font>
</div>
<div class="row">
<div class="container-fluid" id="div1" style="">
<div  class="col-sm-12" style="margin-top:3px;height:500px;background-color:#F3EAE8">
<div class="col-sm-3">
<img id="image1" src="s1.jpg" >
</img>
<br><br>
<font size="3px" color="black" style="font-family:Georgia, serif;" >Saffron Bulbs (Crocus Sativus) 10/+ Top-Size Non-Organic</font>
<br><font style="font-family:Georgia, serif;" size="3px" color="black"><b>3000 ₹(Type = d1)</b></font>
<br><a href="cart.php" id="b1" name="b1"><font >Buy Now</font></a>
</div>
<div class="col-sm-3">
<img id="image1"  src="s2.jpg">
</img>
<br>
<br>
<font size="3px" color="black" style="font-family:Georgia, serif;" >Saffron Bulbs (Crocus Sativus) Bulb Size 9/10 Non-Organic</font>
<br><font style="font-family:Georgia, serif;" size="3px" color="black"><b>2500 ₹(Type = d2)</b></font><br><a href="cart.php" id="b1" name="b2"><font >Buy Now</font></a>
</div>
<div class="col-sm-3">
<img id="image1" src="s3.jpg">
</img>
<br><br>
<font size="3px" color="black" style="font-family:Georgia, serif;" >Saffron Bulbs (Crocus Sativus) Bulb Size 8/9 Non-Organic</font>
<br><font style="font-family:Georgia, serif;" size="3px" color="black"><b>2000 ₹(Type = d3)</b></font><br><a href="cart.php" id="b1" name="b3"><font >Buy Now</font></a>
</div>
<div class="col-sm-3">
<img id="image1" src="s4.jpg">
</img>
<br><br>
<font size="3px" color="black" style="font-family:Georgia, serif;" >Saffron Bulbs (Crocus Sativus)10/+ Top-Size Organic</font>
<br><font style="font-family:Georgia, serif;" size="3px" color="black"><b>4500 ₹(Type = d4)</b></font><br><a href="cart.php" id="b1" name="b4"><font >Buy Now</font></a>
</div>
</div>
</div>
<div class="row" style="margin-top:5px;height:400px;background-color:#0C0C0C">
<div class="col-sm-3">
<font style="position:absolute;top:50px;left:130px" color="white"><h3 >Jump To :</h3></font>
<div style="position:absolute;top:130px;left:130px">
 &rarr; <a href="Home.php"><font color="white">Home</font></a>
 <br><br>
  &rarr; <a href="Aboutus.php"><font color="white">About Us</font></a>
<br> <br>
 &rarr; <a href="#"><font color="white">Our Quality</font></a>
  <br><br>
  &rarr; <a href="Contactus.php"><font color="white">Contact Us</font></a>
 </div>
 </div>
<div class="col-sm-3">
<font style="position:absolute;top:50px;left:130px" color="white"><h3 >The Saffron Blog:</h3></font>

<div style="position:absolute;top:130px;left:130px">
<img src="last1.jpg" height="30px" width="30px"></img>&nbsp;&nbsp;<a href="#" style="text-decoration:none"><font size="2px" color="red">Growing Saffron in Southern<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hemisphere Markets</font></a>
<br><br>
<img src="last2.png" height="30px" width="30px"></img>&nbsp;&nbsp;<a href="#" style="text-decoration:none"><font size="2px" color="red">Bulb Size of Crocus Sativus <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;versus Saffron yield</font></a>
<br><br>
<img src="last3.png" height="30px" width="30px"></img>&nbsp;&nbsp;<a href="#" style="text-decoration:none"><font size="2px" color="red">Growing Saffron in Southern<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hemisphere Markets</font></a>
<br><br>

<img src="last4.png" height="30px" width="30px"></img>&nbsp;&nbsp;<a href="#" style="text-decoration:none"><font size="2px" color="red">Growing Saffron in Southern<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hemisphere Markets</font></a>
</div>
</div>
<div class="col-sm-3">
<font style="position:absolute;top:50px;left:130px" color="white"><h3 >Popular Topics :</h3></font>
<div style="position:absolute;top:130px;left:130px">
<a href="#" id="a1" style="padding:10px 10px 10px 10px;text-decoration:none;border:1px solid black"><font color="#C6C5C5">Crocus Sativus</font></a>
<br><br><a href="#" id="a1" style="padding:10px 10px 10px 10px;text-decoration:none;border:1px solid black"><font color="#C6C5C5">Maximise Saffron Harvest</font></a>
<br><br><a href="#" id="a1" style="padding:10px 10px 10px 10px;text-decoration:none;border:1px solid black"><font color="#C6C5C5">Reproduction Saffron Bulbs</font></a>
<br><br><a href="#" id="a1" style="padding:10px 10px 10px 10px;text-decoration:none;border:1px solid black"><font color="#C6C5C5">Saffron Bulbs</font></a>
</div>
</div>
<div class="col-sm-3">
<font style="position:absolute;top:50px;left:100px" color="white"><h3 >Catagories :</h3></font>
<div style="position:absolute;top:130px;left:100px">
&nbsp;&nbsp;&nbsp;&nbsp;
<a href="www.facebook.com"><i class="fa fa-facebook-official" style="font-size:24px"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="www.youtube.com"><i class="fa fa-youtube-play" style="font-size:24px"></i></a>

</div>

</div>

</div>

<div class="row" style="height:50px;background-color:black">
<div class="col-sm-3">
<font style="position:absolute;top:20px;left:50px">©2018 - Roco Saffron</font>
</div>
<div class="col-sm-1">
</div>
<div class="col-sm-4">
<div style="position:absolute;top:20px;left:170px">
<img src="h1.png" height="20px" width="20px"></img>
<img src="h2.png" height="20px" width="20px"></img>
<img src="h3.jpg" height="20px" width="20px"></img>
</div>
<font style="position:absolute;top:20px;left:100px">Pay With</font>



</div>

<div class="col-sm-1">

</div>
<div class="col-sm-3">
<font style="position:absolute;top:20px">Wholesale Saffron Bulbs (Crocus Sativus)</font>
</div>
</div>
</body>
</html>