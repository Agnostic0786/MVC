<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
#ab:link, #ab:visited {
    background-color: #C52D36 ;
    color: white;
    padding: 14px 25px;
    text-align: center; 
    margin-top:15px;
    display: inline-block;
    font-size:16px;
	font-family:"Arial Black", Gadget, sans-serif;
}

#ab:hover, #ab:active {
    background-color:;
	text-decoration:none;
}
u
{
	   padding-bottom:28px;
	 text-decoration: none;
}
u:hover
{
    border-bottom-width:large;
	border-bottom:10px solid #D6545C  ;
}
#b1 {
    background-color: #8CDD44    ; 
    border: none;
    color: white;
    text-align:center;
    padding : 17px 2px 2px 2px;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	position:absolute; 
	top:320px;  
	left : 20px;
	text-align: center;
	height:60px;
	width:110px;
}
#b1:hover
{
	background-color : #89C454  ;
}
#b2
{
	background-color:transparent;
	  border: 2px solid white;
    color: white;
  text-align:center;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	position:absolute; 
	left :50px;
	top :320px;
	text-align: center;
	margin-left:100px;
	height:60px;
	width:230px;
	padding : 17px 2px 2px 2px;
}
#b2:hover
{
	border:2px solid #B2BABB  ;
}
#id1:hover{
	opacity : 0.5;
}
#id2:hover
{
	display : block;
}
#a1:hover
{
	border: 2px solid white;
}
.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #3E3E42 ;
    min-width: 200px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    padding: 10px 10px 10px 10px;
    z-index: 1;
	
}

.dropdown:hover .dropdown-content {
    display: block;
}
</style>
</head>
<body>
<div class="container-fluid">
<div class="row" >
<div class="col-sm-12" style="height:60px;background-color:#3E3E42   ">
<div class="col-sm-3" style="height:60px;" >
<img src="1st.png"></img>
<a href="#"><font style="font-family:Georgia, serif;color:white">Shop Now for US</font></a>
</div>
<div class="col-sm-3" >
<img src="2nd.png"></img>
<a href="#"><font style="font-family:Georgia, serif;color:white">Shop Now For EU countries</font></a>
</div>
<div class="col-sm-3" >
<font style="position:absolute;top:20px;font-family:Georgia, serif;color:white">&#x260F;+31 6162 46 981</font>
</div>
<div class="col-sm-3" >
<a href="#"><font style="position:absolute;top:20px;font-family:Georgia, serif;color:white">Whole Sale Saffron bulbs(Roco Sativus)</font></a>

</div>

</div>
</div>
<div class="row" style="box-shadow: 2px 2px #AFAFAF  ;">
<div class="col-sm-4" style="height:90px;background-image: url('i1.png');background-repeat: no-repeat;background-position:center center">
</div>
<div class="col-sm-8" style="height:90px;background-color:#C52D36  ">
<a id="ab" href="Home.php" ><u>Home</u></a>
<a id="ab" href="Aboutus.php" ><u>About Us</u></a>
<div class="dropdown">
  <span><a id="ab" href="Ourquality.php" ><u>Our Quality</u></a></span>
  <div class="dropdown-content">
    <a style="font-family:'Arial Black', Gadget, sans-serif;padding:10px 10px 10px 9px;text-decoration:none;" href="ourquality.php"><font color="white">Our Quality</font></a>
	<br>
	<a style="font-family:'Arial Black', Gadget, sans-serif;padding:10px 10px 10px 9px;text-decoration:none" href="farms.php"><font color="white">Our Quality & Farms</font></a>
  </div>
</div>
<a id="ab" href="Shop.php" ><u>Shop</u></a>
<a id="ab" href="Blog.php" ><u>The Saffron Blog</u></a>
<a id="ab" href="Contactus.php" ><u>Contact Us</u>	</a>
</div>
</div>
<div class="row" style="height:500px;background-image : url('i2.jpg');background-size :100% 100%;background-repeat:no-repeat;box-shadow: 0px 7px #8CDD44;margin-top:2px;">
<div class="col-sm-4">
</div>
<div class="col-sm-4">
<font style="position:absolute; top:100px;left:80px;  text-align: center;font-size:15px;color:#CB4A52;margin-left:6%;font-family:Impact, Charcoal, sans-serif">ENJOY &nbsp;&nbsp;&nbsp;OUR&nbsp;&nbsp;&nbsp; PREMIUM&nbsp;&nbsp;&nbsp; QUALITY</font>
<h1 style="margin-left:-60px; color:#FDFEFE  ;font-size:50px;font-family:Georgia, serif;position:absolute; top:130px;text-align: center;">Wholesale Saffron Bulbs<br>
(Crocus Sativus)</h1>
<a id="b1" href="Shop.php">SHOP NOW</a>
<a id="b2">Our Quality and Farms'</a>
</div>
<div class="col-sm-4">
</div>
</div>
<div class="row" style="height:320px;background-color:#FAEAE7  ;margin-top:20px">
<div class="col-sm-1">
</div>
<div class="col-sm-3" style="height:270px;border:4px solid lightgrey">
<h2 style="margin-left:2px;font-family:Georgia, serif;">Consult <font color="#8CDD44 ">from our <br>Saffron Experts!</font></h2>
<font color="grey"> We provide exceptional servicing with regards to support and questions on receiving the maximum return on your Saffron crop. Roco Saffron is proud to help starting many growers from small quantities growing into a successful large Saffron crop for many years!</font>
<br><a href="#" style="position:absolute;top:230px;color:#D6442A  ;font-family:Georgia, serif; text-decoration:none">CONTACT US FOR YOUR QUESTION&nbsp;></a>
</div>
<div class="col-sm-2" style="height:320px;">
<img src="i3.jpg" height="120px" width="180px";></img>
<h4 style="margin-left:2px;font-family:Georgia, serif;">Our Quality & Farms
</font></h4>
<font color="grey"> Roco Saffron relies on an extensive network with the best Saffron growers in the world. Our crop of Saffron bulbs holds the highest quality certificate in the industry. Read more what...</font>
<br><a href="#" style="position:absolute;top:300px;color:#D6442A  ;font-family:Georgia, serif; text-decoration:none">READ MORE&nbsp;></a>
</div>
<div class="col-sm-2" style="height:320px;">
<img src="i4.jpg" height="120px" width="180px";></img>
<h4 style="margin-left:2px;font-family:Georgia, serif;">The Red Gold
</font></h4>
<font color="grey"> Saffron is the world's most expensive spice and in the industry also called "Red Gold". Saffron is obtained from the stigmas of the Crocus Sativus flower. Saffron counts on a long history...</font>
<br><a href="#" style="position:absolute;top:300px;color:#D6442A  ;font-family:Georgia, serif; text-decoration:none">READ MORE&nbsp;></a>

</div>
<div class="col-sm-2" style="height:320px;">
<img src="i5.jpg" height="120px" width="180px";></img>
<h4 style="margin-left:2px;font-family:Georgia, serif;">Our Customers
</font></h4>
<font color="grey"> Roco Saffron is proud to build strong relationships with their customers worldwide. We often visit our customers on a regular basis for consultation. Check out to see some of our professional...</font>
<br><a href="#" style="position:absolute;top:300px;color:#D6442A  ;font-family:Georgia, serif; text-decoration:none">READ MORE&nbsp;></a>
</div>
</div>
<div class="row" style="margin-top:10px;height:300px;background-color:#3E3E42 ">
<div class="container">
<h2 style="margin-left:2px;text-align:center;font-family:Georgia, serif;"><font color="white">Growing</font><font color="#8CDD44 "> Saffron in 6 steps</font></h2>
<font style="text-align:center" color="white"><center>Saffron is the world's most expensive spice. However, growing the so-called Red Gold is very simple and accessible to anyone. Follow these 6 steps to grow your own fresh Saffron affordably and add a little healthy color to your life! If you still need some help, please don't hesitate to contact our Saffron experts!</center></font>
<div class="row" style="margin-top:30px;">
<div class="col-sm-2">
<font color="white" id="id2" style="display:none">1. Buy Crocus Sativus Bulbs</font>
<img src="i6.jpg" style="border:2px solid lightgrey" id="id1" height="130px" width="180px">
</img>
</div>
<div class="col-sm-2">
<img src="i7.jpg"  id="id1" style="border:2px solid lightgrey" height="130px" width="180px">
</img>
</div><div class="col-sm-2">
<img src="i8.jpg" style="border:2px solid lightgrey" id="id1" height="130px" width="180px">
</img>
</div><div class="col-sm-2">
<img src="i9.jpg" style="border:2px solid lightgrey" id="id1" height="130px" width="180px">
</img>
</div><div class="col-sm-2">
<img src="i10.jpg" style="border:2px solid lightgrey" id="id1" height="130px" width="180px">
</img>
</div><div class="col-sm-2">
<img src="i11.jpg" style="border:2px solid lightgrey"  id="id1" height="130px" width="180px">
</img>
</div>
</div> 
</div>
</div>
<div class="row" style="background-color:#FAEAE7">
<h2 style="margin-left:90px;font-family:Georgia, serif;font-size:50px">About <font color="#8CDD44 ">Roco Saffron</font></h2>
<br>
<font color="grey" style="margin-left:90px"> Roco Saffron is a family company supplying the industry with the finest and premium quality of Saffron bulbs direclty from the farms in the Netherlands since 1882. It was originally founded 
</font><br><font color="grey" style="margin-left:90px"> by the Rotteveel family generations ago distributing flower bulbs such as Tulip & Hyacinth bulbs to Europe & the U.S.A. markets. Roco Saffron (Rotteveel Company) has built up a strong 
</font><br>
<font color="grey" style="margin-left:90px">reputation for their knowledge and consistent quality of Saffron Crocus (Crocus Sativus) bulbs supplying the professional Saffron industry in Southern Europe and the U.S.A. Our aim is to 
</font><br>
<font color="grey" style="margin-left:90px">build long lasting relationships with our customer base around the world and supply the professional Saffron industry with an excellent crop of Saffron bulbs meeting the highest industry 
</font><br>
<font color="grey" style="margin-left:90px">quality standards.</font>
<br><br><a href="#" style="margin-left:90px;color:#D6442A  ;font-family:Georgia, serif; text-decoration:none">MORE ABOUT US&nbsp;></a>
</div>
<div class="row" style="background-color:#FAEAE7">
<h2 style="text-align:center;font-family:Georgia, serif;font-size:50px"> <font color="#8CDD44 ">Our Location</font></h2>
<br><font color="grey" style="margin-left:395px;font-family:Georgia, serif">Roco Saffron is located right in the center of Holland's world famous flower bulb district.</font>
<iframe style="margin-top:4px;margin-left:5px" src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d3410.799932356943!2d75.70530476507564!3d31.253961337312866!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1523523884504" width="1340" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>
<div class="row" style="margin-top:5px;height:400px;background-color:#0C0C0C">
<div class="col-sm-3">
<font style="position:absolute;top:50px;left:130px" color="white"><h3 >Jump To :</h3></font>
<div style="position:absolute;top:130px;left:130px">
 &rarr; <a href="Home.php"><font color="white">Home</font></a>
 <br><br>
  &rarr; <a href="Aboutus.php"><font color="white">About Us</font></a>
<br> <br>
 &rarr; <a href="#"><font color="white">Our Quality</font></a>
  <br><br>
  &rarr; <a href="Contactus.php"><font color="white">Contact Us</font></a>
 </div>
 </div>
<div class="col-sm-3">
<font style="position:absolute;top:50px;left:130px" color="white"><h3 >The Saffron Blog:</h3></font>

<div style="position:absolute;top:130px;left:130px">
<img src="last1.jpg" height="30px" width="30px"></img>&nbsp;&nbsp;<a href="#" style="text-decoration:none"><font size="2px" color="red">Growing Saffron in Southern<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hemisphere Markets</font></a>
<br><br>
<img src="last2.png" height="30px" width="30px"></img>&nbsp;&nbsp;<a href="#" style="text-decoration:none"><font size="2px" color="red">Bulb Size of Crocus Sativus <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;versus Saffron yield</font></a>
<br><br>
<img src="last3.png" height="30px" width="30px"></img>&nbsp;&nbsp;<a href="#" style="text-decoration:none"><font size="2px" color="red">Growing Saffron in Southern<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hemisphere Markets</font></a>
<br><br>

<img src="last4.png" height="30px" width="30px"></img>&nbsp;&nbsp;<a href="#" style="text-decoration:none"><font size="2px" color="red">Growing Saffron in Southern<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hemisphere Markets</font></a>
</div>
</div>
<div class="col-sm-3">
<font style="position:absolute;top:50px;left:130px" color="white"><h3 >Popular Topics :</h3></font>
<div style="position:absolute;top:130px;left:130px">
<a href="#" id="a1" style="padding:10px 10px 10px 10px;text-decoration:none;border:1px solid black"><font color="#C6C5C5">Crocus Sativus</font></a>
<br><br><a href="#" id="a1" style="padding:10px 10px 10px 10px;text-decoration:none;border:1px solid black"><font color="#C6C5C5">Maximise Saffron Harvest</font></a>
<br><br><a href="#" id="a1" style="padding:10px 10px 10px 10px;text-decoration:none;border:1px solid black"><font color="#C6C5C5">Reproduction Saffron Bulbs</font></a>
<br><br><a href="#" id="a1" style="padding:10px 10px 10px 10px;text-decoration:none;border:1px solid black"><font color="#C6C5C5">Saffron Bulbs</font></a>
</div>
</div>
<div class="col-sm-3">
<font style="position:absolute;top:50px;left:100px" color="white"><h3 >Catagories :</h3></font>
<div style="position:absolute;top:130px;left:100px">
&nbsp;&nbsp;&nbsp;&nbsp;
<a href="www.facebook.com"><i class="fa fa-facebook-official" style="font-size:24px"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="www.youtube.com"><i class="fa fa-youtube-play" style="font-size:24px"></i></a>
</div>
</div>

</div>
<div class="row" style="height:50px;background-color:black">
<div class="col-sm-3">
<font style="position:absolute;top:20px;left:50px">©2018 - Roco Saffron</font>
</div>
<div class="col-sm-1">
</div>
<div class="col-sm-4">
<div style="position:absolute;top:20px;left:170px">
<img src="h1.png" height="20px" width="20px"></img>
<img src="h2.png" height="20px" width="20px"></img>
<img src="h3.jpg" height="20px" width="20px"></img>
</div>
<font style="position:absolute;top:20px;left:100px">Pay With</font>



</div>

<div class="col-sm-1">

</div>
<div class="col-sm-3">
<font style="position:absolute;top:20px">Wholesale Saffron Bulbs (Crocus Sativus)</font>
</div>
</div>
</body>
</html>