<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
#ab:link, #ab:visited {
    background-color: #C52D36 ;
    color: white;
    padding: 14px 25px;
    text-align: center; 
    margin-top:15px;
    display: inline-block;
    font-size:16px;
	font-family:"Arial Black", Gadget, sans-serif;
}

#ab:hover, #ab:active {
    background-color:;
	text-decoration:none;
}
u
{
	   padding-bottom:28px;
	 text-decoration: none;
}
u:hover
{
    border-bottom-width:large;
	border-bottom:10px solid #D6545C  ;
}
#b1 {
    background-color: #8CDD44    ; 
    border: none;
    color: white;
    text-align:center;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	position:absolute; 
	top:320px;  
	left : 20px;
	text-align: center;
	height:60px;
	width:110px;
}
#b1:hover
{
	background-color : #89C454  ;
}
#b2
{
	background-color:transparent;
	  border: 2px solid white;
    color: white;
  text-align:center;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	position:absolute; 
	left :50px;
	top :320px;
	text-align: center;
	margin-left:100px;
	height:60px;
	width:230px;
}
#b2:hover
{
	border:2px solid #B2BABB  ;
}
#id1:hover{
	opacity : 0.5;
}
#id2:hover
{
	display : block;
}
</style>
</head>
<body>
<div class="container-fluid">
<div class="row" >
<div class="col-sm-12" style="height:60px;background-color:#3E3E42   ">
<div class="col-sm-3" style="height:60px;" >
<img src="1st.png"></img>
<a href="#"><font style="font-family:Georgia, serif;color:white">Shop Now for US</font></a>
</div>
<div class="col-sm-3" >
<img src="2nd.png"></img>
<a href="#"><font style="font-family:Georgia, serif;color:white">Shop Now For EU countries</font></a>
</div>
<div class="col-sm-3" >
<font style="position:absolute;top:20px;font-family:Georgia, serif;color:white">&#x260F;+31 6162 46 981</font>
</div>
<div class="col-sm-3" >
<a href="#"><font style="position:absolute;top:20px;font-family:Georgia, serif;color:white">Whole Sale Saffron bulbs(Roco Sativus)</font></a>

</div>
</div>
</div>
<div class="row" style="box-shadow: 2px 2px #AFAFAF  ;">
<div class="col-sm-4" style="height:90px;background-image: url('i1.png');background-repeat: no-repeat;background-position:center center">
</div>
<div class="col-sm-8" style="height:90px;background-color:#C52D36  ">
<a id="ab" href="Home.php" ><u>Home</u></a>
<a id="ab" href="Aboutus.php" ><u>About Us</u></a>
<a id="ab" href="Ourquality.php" ><u>Our Quality</u></a>
<a id="ab" href="Shop.php" ><u>Shop</u></a>
<a id="ab" href="Blog.php" ><u>The Saffron Blog</u></a>
<a id="ab" href="Contactus.php" ><u>Contact Us</u>	</a>
</div>
</div>
<div class="row" style="background-color:#F3EAE8;height:150px">
<h1 style="margin-left:70px;font-family:Georgia, serif;font-size:50px">About Us</h1>
<font color="grey" style="margin-left:70px">Wholesale Premium Quality Saffron Bulbs | Crocus Sativus</font>
</div>
<div class="row" style="height:800px;background-color:#FCFBFB  ">
<div class="col-sm-4">
</div>
<div class="col-sm-4" style="margin-top:50px">
<h1 style="margin-left:px;font-family:Georgia, serif;font-size:">Roco <font color="#8CDD44">Saffron (1882)</font></h1>
<font color="grey" style="font-family:Georgia, serif;">Roco Saffron (Rotteveel Company) is a family company supplying the industry with the finest and premium quality of Saffron bulbs direclty from the farms in the Netherlands since 1882. It was originally founded by the Rotteveel family Four Generations ago distributing flower bulbs such as Tulip & Hyacinth bulbs to Europe & the U.S.A. markets.

Our Fourth Generation family member Hans Rotteveel has been involved in the Flower Bulb business since a child. Hans has traveled throughout Europe & the U.S.A. visiting customers and supplying the finest quality of flower bulbs from Holland. Hans Rotteveel soon found out that his passion and heart was devoted to the Saffron industry, therefore Hans decided to fully dedicate working with professional Saffron growers from all over the world supplying not only his expertise about Saffron but also premium quality Saffron Bulbs. Roco Saffron is a Rotteveel company with a focus and specialization in Saffron Bulbs only.

Roco Saffron has built up a strong reputation for their knowledge and consistent quality of Saffron Crocus (Crocus Sativus) bulbs supplying the professional Saffron industry in Southern Europe and the U.S.A.

Our aim is to build long lasting relationships with our customer base around the world and supply the professional Saffron industry with an excellent crop of Saffron bulbs meeting the highest industry quality standards.

Yours sincerely, Cordiali saluti, Sinceramente,</font><br><br>
<img src="sign.png"></img><br>
<b>Hans Rotteveel</b><br>
<i>President Roco Saffron</i>
</div>
<div class="col-sm-4" style="margin-top:80px">
<img src="a1.jpg" style="margin-top:px" height="220px" width="350px"></img><br>
<img src="a2.jpg" style="margin-top:3px" height="220px" width="350px"></img><br>
<img src="a3.jpg" height="220px" style="margin-top:3px" width="350px"></img><br>

</div>
</div>
<div class="row" style="margin-top:5px;height:400px;background-color:#0C0C0C">
<div class="col-sm-3">
<font style="position:absolute;top:50px;left:130px" color="white"><h3 >Jump To :</h3></font>
<div style="position:absolute;top:130px;left:130px">
 &rarr; <a href="Home.php"><font color="white">Home</font></a>
 <br><br>
  &rarr; <a href="Aboutus.php"><font color="white">About Us</font></a>
<br> <br>
 &rarr; <a href="#"><font color="white">Our Quality</font></a>
  <br><br>
  &rarr; <a href="Contactus.php"><font color="white">Contact Us</font></a>
 </div>
 </div>
<div class="col-sm-3">
<font style="position:absolute;top:50px;left:130px" color="white"><h3 >The Saffron Blog:</h3></font>

<div style="position:absolute;top:130px;left:130px">
<img src="last1.jpg" height="30px" width="30px"></img>&nbsp;&nbsp;<a href="#" style="text-decoration:none"><font size="2px" color="red">Growing Saffron in Southern<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hemisphere Markets</font></a>
<br><br>
<img src="last2.png" height="30px" width="30px"></img>&nbsp;&nbsp;<a href="#" style="text-decoration:none"><font size="2px" color="red">Bulb Size of Crocus Sativus <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;versus Saffron yield</font></a>
<br><br>
<img src="last3.png" height="30px" width="30px"></img>&nbsp;&nbsp;<a href="#" style="text-decoration:none"><font size="2px" color="red">Growing Saffron in Southern<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hemisphere Markets</font></a>
<br><br>

<img src="last4.png" height="30px" width="30px"></img>&nbsp;&nbsp;<a href="#" style="text-decoration:none"><font size="2px" color="red">Growing Saffron in Southern<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hemisphere Markets</font></a>
</div>
</div>
<div class="col-sm-3">
<font style="position:absolute;top:50px;left:130px" color="white"><h3 >Popular Topics :</h3></font>
<div style="position:absolute;top:130px;left:130px">
<a href="#" id="a1" style="padding:10px 10px 10px 10px;text-decoration:none;border:1px solid black"><font color="#C6C5C5">Crocus Sativus</font></a>
<br><br><a href="#" id="a1" style="padding:10px 10px 10px 10px;text-decoration:none;border:1px solid black"><font color="#C6C5C5">Maximise Saffron Harvest</font></a>
<br><br><a href="#" id="a1" style="padding:10px 10px 10px 10px;text-decoration:none;border:1px solid black"><font color="#C6C5C5">Reproduction Saffron Bulbs</font></a>
<br><br><a href="#" id="a1" style="padding:10px 10px 10px 10px;text-decoration:none;border:1px solid black"><font color="#C6C5C5">Saffron Bulbs</font></a>
</div>
</div>
<div class="col-sm-3">
<font style="position:absolute;top:50px;left:100px" color="white"><h3 >Categories :</h3></font>
<div style="position:absolute;top:130px;left:100px">
&nbsp;&nbsp;&nbsp;&nbsp;
<a href="www.facebook.com"><i class="fa fa-facebook-official" style="font-size:24px"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="www.youtube.com"><i class="fa fa-youtube-play" style="font-size:24px"></i></a>

</div>

</div>

</div>

<div class="row" style="height:50px;background-color:black">
<div class="col-sm-3">
<font style="position:absolute;top:20px;left:50px">©2018 - Roco Saffron</font>
</div>
<div class="col-sm-1">
</div>
<div class="col-sm-4">
<div style="position:absolute;top:20px;left:170px">
<img src="h1.png" height="20px" width="20px"></img>
<img src="h2.png" height="20px" width="20px"></img>
<img src="h3.jpg" height="20px" width="20px"></img>
</div>
<font style="position:absolute;top:20px;left:100px">Pay With</font>



</div>

<div class="col-sm-1">

</div>
<div class="col-sm-3">
<font style="position:absolute;top:20px">Wholesale Saffron Bulbs (Crocus Sativus)</font>
</div>
</div>
</body>
</html>