<!DOCTYPE html>
<html>
<head>
	 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">	
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script>
function changeImageOnClick()
{
var tElement=event.target;
if(tElement.tagName=="IMG")
{
a=tElement.getAttribute("src");
document.getElementById("mainImage").setAttribute("src",a);
}
}
var intervalid;
function startImageSlideShow()
{
intervalid= setInterval(setImage,2000);
}
function stopImageSlideShow()
{
clearInterval(intervalid);
}
function setImage()
{
  var imageSrc=document.getElementById("mainImage").getAttribute("src");
  var currentImageNumber=imageSrc.substring(imageSrc.lastIndexOf("/")+1,imageSrc.lastIndexOf("/")+2);
  if(currentImageNumber==6)
{
  currentImageNumber=0;
}
document.getElementById("mainImage").setAttribute("src",""  +(Number(currentImageNumber)+1)+".jpg");
}
</script>
 <style type="text/css">
.myStyle
{
height :90px;
width:160px;
margin-left:1.3px;	
}
.ab:link, .ab:visited {
    background-color: #0074DB;
    color: black;
    height: 60px;
    padding: 20px 20px 20px 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    border-radius: 4px;
}
.ab:hover, .ab:active {
    background-color: #6F82F7;
}
input[type=text] {
	margin-top: 16px;
    width: 10px;
    height: 25px;
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 10px;
    color: black;
    border-color:  #2E86C1;
    background-color: #D6DBDF;
    background-position: 10px 10px; 
    background-repeat: no-repeat;
    padding: 12px 20px 12px 40px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
}
input[type=text]:focus {
    width: 90%;
}		
.abc:hover{
background-color: darkgrey;
}
 </style>
</head>
<body background="white">
<div class="container-fluid">
	<div class="row" style="height:60px;background-color: #0074DB;box-shadow: 10px 10px 50px #D4E6F1   ;">
		<div class="col-sm-2" style=""><img src="microsoft.png" style="width:150px;margin-top: 10px;"/></div>
	    <div class="col-sm-1" style=""><a href="/windows" class="ab" target="_blank">Windows</a></div>
		<div class="col-sm-1" style=""><a href="#" class="ab" target="_blank">Surface</a></div>
		<div class="col-sm-1" style=""><a href="#" class="ab" target="_blank">XBOX</a></div>
		<div class="col-sm-1" style=""><a href="/office" class="ab" target="_blank">Office</a></div>
		<div class="col-sm-1" style=""><a href="/support" class="ab" target="_blank">Support</a></div>
		<div class="col-sm-3" style=""><input type="text" name="search" placeholder="Search Microsoft.."/><i class="glyphicon glyphicon-search"></i></div>
		<div class="col-sm-1" style=""> <a href="" class="ab">
          <span class="glyphicon glyphicon-shopping-cart"></span>
        </a></div>
        <div class="col-sm-1" style=""><a style="margin-top:-2px" href="/sign1" class="ab" target="_top">SignIn</a></div>
	</div>
	
	<div class="row" style="background-color: lightgrey;height: 500px;margin-top: 2px;box-shadow: 10px 10px 50px #CACFD2  ;">
	<div class="col-sm-12">
		<body onload="startImageSlideShow()">
       <img id="mainImage" style="border:3px solid grey" src="1.jpg" height="500px" width="1330px"/>
       <div id="divId" onclick="changeImageOnClick()">
       <img class="myStyle" src="1.jpg"/>
       <img class="myStyle" src="2.jpg"/>
       <img class="myStyle" src="3.jpg"/>
       <img class="myStyle" src="4.jpg"/>
       <img class="myStyle" src="5.jpg"/>
       <img class="myStyle" src="6.jpg"/>  
       <img class="myStyle" src="7.jpg"/>  
       <img class="myStyle" src="8.jpg"/>  
            
      </div>
	</div>
	</div>
	<div class="row" style="background-color: white;height: 380px;margin-top: 100px;box-shadow: 10px 10px 50px #CACFD2  ;">
		<div class="col-sm-2"><img src="Xbox1.jpg" style="width:230px;height:150px;margin-left:px;margin-top: 3px"><img>
			<h3>XBOX ONE S</h3>
			<font style="font-family:'Lucida Console', Monaco, monospace">The ultimate games and 4K entertainment system.</font>
			<br><a href="#"><u>LEARN MORE  &nbsp;&nbsp;></u>	</a></div>
		<div class="col-sm-1"></div>
		<div class="col-sm-2"><img src="windows10.jpg" style="width:230px;height:150px;margin-top: 3px"><img>
		<h3>WINDOWS 10</h3>
			<font style="font-family:'Lucida Console', Monaco, monospace">Learn more about 3D, Windows Mixed Reality and more.</font>
			<br><br><a href="#"><u>WINDOWS 10 FALL CREATORS UPDATE &nbsp;&nbsp; ></u></a></div>
		<div class="col-sm-1"></div>
		<div class="col-sm-2"><img src="outllok.jpg" style="width:230px;height:150px;margin-top: 3px"><img>
			<h3>Outlook</h3>
			<font style="font-family:'Lucida Console', Monaco, monospace">The free email app for iOS, Android and Windows.</font>
		<br><br><a href="#"><u>DOWNLOAD NOW  &nbsp;&nbsp;></u></a></div>
		<div class="col-sm-1"></div>
		<div class="col-sm-2"><img src="onenote.jpg" style="width:230px;height:150px;margin-top: 3px"><img>
		<h3>OneNote</h3>
			<font style="font-family:'Lucida Console', Monaco, monospace">Organise your notes and your life.</font>
<br><br><br><a href="#"><u>DOWNLOAD ONE NOTE FOR FREE&nbsp;&nbsp; > </u></a>
	    </div>
	</div>
	<div class="row" style="height: 400px ;margin-top: 2px;box-shadow: 10px 10px 50px #CACFD2">
		<div class="col-sm-12" style="height: 400px;background-image: url('other.jpg');background-size: 1360px 565px">
			<h3 style="color:white;margin-top:80px">MICROSOFT STORE</h3>
			<font style="font-family:'Lucida Console', Monaco, monospace" color="white">Find the technology you need for work, school, home and fun.</font><br>	
			<a href="#" class="abc" style="color:white ;font-family:'Lucida Console', Monaco, monospace;margin-top: 2px;padding:10px 0px 10px 0px;text-align: center;display:inline-block; border-radius: 2px">SHOP NOW&nbsp;></a>
		</div>
	</div>
	<div class="row" style="height : 70px;background-color:white">
		<div class="col-sm-12" style="margin-top: 10px">
			<font sixe="5px" style="margin-left : 500px;margin-top:5px;font-family:'Lucida Console', Monaco, monospace "><b>FOLLOW US</b></font>
				<a href="www.facebook.com" style="text-decoration :none">
  <img src="link1.jpg" style="width:42px;height:42px;border:0;">
</a>&nbsp;
			<a href="www.twitter.com" style="text-decoration :none">
  <img src="link2.jpg" style="width:42px;height:42px;border:0;">
</a>&nbsp;
		<a href="www.linkedin.com" style="text-decoration :none">
  <img src="link3.jpg" style="width:42px;height:42px;border:0;">
</a>&nbsp;
		<a href="www.youtube.com" style="text-decoration :none">
  <img src="link4.png" style="width:42px;height:42px;border:0;">
</a>&nbsp;
		</div>
	</div> 
	<div class="row" style="height : 400px;margin-top: 2px;background-color : lightgrey">
		<div class="col-sm-2">
		 <font >  <b>What's new</b><br><br>
           Surface Pro<br><br>
           Windows 10 apps<br><br>
           Office apps<br></font>
		</div>
		<div class="col-sm-2">
	<font>		
<b>Surface Pro</b><br><br>
Windows 10 apps<br><br>
Office apps<br><br>
Store & Support<br><br>
Account profile<br><br>
Download Center<br><br>
Sales & support<br><br>
Returns<br><br>
Order tracking<br><br>
Support</font>
		</div>
		<div class="col-sm-2">
			<font><b>Education</b><br><br>
Microsoft in education<br><br>
Office for students<br><br>
Office 365 for schools<br><br>
Deals for students & parents<br><br>
Microsoft Azure in education</font>
		</div>
		<div class="col-sm-2">
			
<font><b>Enterprise</b><br><br>
Microsoft Azure<br><br>
Enterprise<br><br>
Data platform<br><br>
Microsoft partner resources<br><br>
Manufacturing & resources<br><br>
Financial services</b></font>
		</div>
		<div class="col-sm-2">
			<font><b>Developer</b><br><br>
Microsoft Visual Studio<br><br>
Developer Network<br><br>
TechNet<br><br>
Microsoft Virtual Academy<br><br>
Channel 9<br><br>
Office Dev Center</font>
		</div>
		<div class="col-sm-2">
			<font><b>Company</b><br><br>
Careers<br><br>
About Microsoft<br><br>
Company news<br><br>
Privacy at Microsoft<br><br>
Investors<br><br>
Security</font>
		</div>
		
	</div>
	<div class="row" style="height : 50px;background-color: lightgrey;margin-bottom: 5px">
		<div class="col-sm-1"></div>
		<div class="col-sm-1"></div>
		<div class="col-sm-1"></div>
		<div class="col-sm-1"></div>
		<div class="col-sm-1"></div>
		<div class="col-sm-1"></div>
		<div class="col-sm-1">Contact us</div>
		<div class="col-sm-1">  Privacy & cookies</div>
		<div class="col-sm-1">  Terms of use</div>
		<div class="col-sm-1">  Trademarks</div>
		<div class="col-sm-1">  About our ads</div>
		<div class="col-sm-1">  © Microsoft 2018</div>
		
	</div>
	</div>
</div>
</body>
</html>