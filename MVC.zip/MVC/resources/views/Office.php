<!DOCTYPE html>
<html>
<head>
    
         <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 <style type="text/css">
.myStyle
{
height :90px;
width:160px;
margin-left:1.3px;  
}
.ab:link, .ab:visited {
    background-color: #E8E9F3  ;
    color: black;
    height: 60px;
    padding: 20px 20px 20px 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    border-radius: 4px;
}
.ab:hover, .ab:active {
    background-color: #6F82F7;
}
input[type=text] {
    margin-top: 16px;
    width: 10px;
    height: 25px;
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 10px;
    color: black;
    border-color:  #2E86C1;
    background-color: #D6DBDF;
    background-position: 10px 10px; 
    background-repeat: no-repeat;
    padding: 12px 20px 12px 40px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
}
input[type=text]:focus {
    width: 90%;
}       
.abc:hover{
background-color: darkgrey;
}
#a1:link, #a1:visited {
    background-color: #f44336;
    color: white;
    padding: 14px 25px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    height : 70px;
    width  : 100px;
}


#a1:hover, #a1:active {
    background-color: #A93226  ;
}
</style>
    </head>
    <body background="white">
<div class="container-fluid">
    <div class="row" style="height:60px;background-color: #E8E9F3  ;box-shadow: 10px 10px 50px #D4E6F1   ;">
        <div class="col-sm-2" style=""><img src="microsoft.png" style="width:150px;margin-top: 10px;"/></div>
        <div class="col-sm-1" style=""><a href="/windows" class="ab" target="_blank">Windows</a></div>
        <div class="col-sm-1" style=""><a href="#" class="ab" target="_blank">Surface</a></div>
        <div class="col-sm-1" style=""><a href="#" class="ab" target="_blank">XBOX</a></div>
        <div class="col-sm-1" style=""><a href="/office" class="ab" target="_blank">Office</a></div>
        <div class="col-sm-1" style=""><a href="/support" class="ab" target="_blank">Support</a></div>
        <div class="col-sm-3" style=""><input type="text" name="search" placeholder="Search Microsoft.."/><i class="glyphicon glyphicon-search"></i></div>
        <div class="col-sm-1" style=""> <a href="" class="ab">
          <span class="glyphicon glyphicon-shopping-cart"></span>
        </a></div>
        <div class="col-sm-1" style=""><a style="margin-top:-2px" href="/sign1" class="ab" target="_top">SignIn</a></div>
    </div>
    
    <div class="row" style="height:500px;background-image: url('o1.jpg');background-size: 1370px 500px">
        <div class="col-sm-6"></div>
        <div class="col-sm-6">
             <h1 style="margin-left:250px;margin-top:60px;color:#5D6D7E    ;font-family:'Lucida Console', Monaco, monospace">What will you do<br> with your next<br> 365?
</h1>
<h4 style="margin-left:250px;margin-top:40px;color:#5D6D7E    ;font-family:'Lucida Console', Monaco, monospace">With Office, you have 365 days ahead of you filled with endless possibilities. And it starts now.
</h4>
<div class="row">
<div class="col-sm-3"><a id="a1" href="https://products.office.com/en-in/compare-all-microsoft-office-products?tab=1" style="margin-left: 250px;margin-top: ">For Home</a></div>
<div class=col-sm-3><a id="a1" href="https://products.office.com/en-in/business/office" style="margin-left: 200px;margin-top: px">For Business</a> </div>
</div>      </div>
    </div>
    </div>
    </body>
</html>