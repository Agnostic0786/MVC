<!DOCTYPE html>
<html>
<head>
	 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">	
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 <style type="text/css">
.myStyle
{
height :90px;
width:160px;
margin-left:1.3px;	
}
.ab:link, .ab:visited {
    background-color: #E8E9F3  ;
    color: black;
    height: 60px;
    padding: 20px 20px 20px 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    border-radius: 4px;
}
.ab:hover, .ab:active {
    background-color: #6F82F7;
}
input[type=text] {
	margin-top: 16px;
    width: 10px;
    height: 25px;
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 10px;
    color: black;
    border-color:  #2E86C1;
    background-color: #D6DBDF;
    background-position: 10px 10px; 
    background-repeat: no-repeat;
    padding: 12px 20px 12px 40px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
}
input[type=text]:focus {
    width: 90%;
}		
.abc:hover{
background-color: darkgrey;
}
#id1
{
	margin-top: 16px;
    width: 130px;
    height: 35px;
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 20px;
    color: black;
    border-color:  #2E86C1;
    background-color: #D6DBDF;
    background-position: 10px 10px; 
    background-repeat: no-repeat;
    padding: 12px 20px 12px 40px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
}
#id1:focus {
    width: 90%;
}	

/* When the screen is less than 600px wide, stack the links and the search field vertically instead of horizontally */

 </style>
 <body background="white">
<div class="container-fluid">
	<div class="row" style="height:60px;background-color: #E8E9F3  ;box-shadow: 10px 10px 50px #D4E6F1   ;">
		<div class="col-sm-2" style=""><img src="microsoft.png" style="width:150px;margin-top: 10px;"/></div>
	    <div class="col-sm-1" style=""><a href="/windows" class="ab" target="_blank">Windows</a></div>
		<div class="col-sm-1" style=""><a href="#" class="ab" target="_blank">Surface</a></div>
		<div class="col-sm-1" style=""><a href="#" class="ab" target="_blank">XBOX</a></div>
		<div class="col-sm-1" style=""><a href="/office" class="ab" target="_blank">Office</a></div>
		<div class="col-sm-1" style=""><a href="/support" class="ab" target="_blank">Support</a></div>
		<div class="col-sm-3" style=""><input type="text" name="search" placeholder="Search Microsoft.."/><i class="glyphicon glyphicon-search"></i></div>
		<div class="col-sm-1" style=""> <a href="" class="ab">
          <span class="glyphicon glyphicon-shopping-cart"></span>
        </a></div>
        <div class="col-sm-1" style=""><a style="margin-top:-2px" href="/sign1" class="ab" target="_top">SignIn</a></div>
	</div>
	<div class="row" style="height:60px;background-color: #2736CF">
		<h3 style="color:white;margin-top:10px;font-family:'Lucida Console', Monaco, monospace">Microsoft Support</h3>
	</div>
	<div class="row" style="height:300px;background-color:lightgrey">
		<div class="col-sm-6">
		<h2 style="color:black;margin-top:100px;font-family:'Lucida Console', Monaco, monospace">Welcome to Microsoft Support</h2>
		<div class="topnav">
  <input type="text" id="id1" placehoder="Search..">
</div>
</div>
		<div class="col-sm-6" style="height:300px;margin-top:75px;background-image: url('support.jpg');background-repeat: no-repeat">
	</div>
</div>
		<h2 style="color:black;margin-left:360px;margin-top:100px;font-family:'Lucida Console', Monaco, monospace">Which Product do you need help with?</h2>
		<div class="row" style="margin-left:20px">
			<div class="col-sm-2">
				<img src="s1.jpg" style="height:100px;width:100px"/><br>
				<a href="https://support.microsoft.com/en-in/products/windows?os=windows-10" style="margin-left:20px">WINDOWS</a>
			</div>
			<div class="col-sm-2">
				<img src="s2.png" style="margin-top:7px;height:70px;width:70px"/><br><br>
				<a href="https://support.office.com/en-in" style="margin-left:10px">OFFICE</a>
			</div>
				<div class="col-sm-2">
				<img src="s3.png" style="margin-top:7px;height:70px;width:70px"/><br><br>
				<a href="https://support.office.com/en-in/outlook" style="margin-left:10px">OUTLOOK</a>
			</div>
				<div class="col-sm-2">
				<img src="s4.png" style="margin-top:7px;height:70px;width:70px"/><br><br>
				<a href="https://support.microsoft.com/en-in/products/microsoft-account/" style="margin-left:-40px">MICROSOFT ACCOUNT</a>
			</div>
				<div class="col-sm-2">
				<img src="s5.gif" style="margin-top:7px;height:70px;width:70px"/><br><br>
				<a href="https://support.xbox.com/en-in" style="margin-left:20px">XBOX</a>
			</div>
				<div class="col-sm-2">
				<img src="s6.png" style="margin-top:7px;height:60px;width:60px"/><br><br>
				<a href="https://support.microsoft.com/en-in/products/microsoft-store/" style="margin-left:-35px">MICROSOFT STORE</a>
			</div>

		</div>
		<br><br>
		<br>
		<a href="https://support.microsoft.com/en-in/allproducts" style="margin-left:53	0px">VIEW ALL MICROSOFT PRODUCTS</a>
		<br>
		<br>
		<div class="row" style="height : 400px;margin-top: 2px;background-color : lightgrey">
		<div class="col-sm-2">
     <font >  <b>What's new</b><br><br>
           Surface Pro<br><br>
           Windows 10 apps<br><br>
           Office apps<br></font>
		</div>
		<div class="col-sm-2">
	<font>		
<b>Surface Pro</b><br><br>
Windows 10 apps<br><br>
Office apps<br><br>
Store & Support<br><br>
Account profile<br><br>
Download Center<br><br>
Sales & support<br><br>
Returns<br><br>
Order tracking<br><br>
Support</font>
		</div>
		<div class="col-sm-2">
			<font><b>Education</b><br><br>
Microsoft in education<br><br>
Office for students<br><br>
Office 365 for schools<br><br>
Deals for students & parents<br><br>
Microsoft Azure in education</font>
		</div>
		<div class="col-sm-2">
			
<font><b>Enterprise</b><br><br>
Microsoft Azure<br><br>
Enterprise<br><br>
Data platform<br><br>
Microsoft partner resources<br><br>
Manufacturing & resources<br><br>
Financial services</b></font>
</div>
		
		<div class="col-sm-2">
			<font><b>Developer</b><br><br>
Microsoft Visual Studio<br><br>
Developer Network<br><br>
TechNet<br><br>
Microsoft Virtual Academy<br><br>
Channel 9<br><br>
Office Dev Center</font>
		</div>
		<div class="col-sm-2">
			<font><b>Company</b><br><br>
Careers<br><br>
About Microsoft<br><br>
Company news<br><br>
Privacy at Microsoft<br><br>
Investors<br><br>
Security</font>
		</div>
</div>
	<div class="row" style="height : 50px;background-color: lightgrey;margin-bottom: 5px">
		<div class="col-sm-1"></div>
		<div class="col-sm-1"></div>
		<div class="col-sm-1"></div>
		<div class="col-sm-1"></div>
		<div class="col-sm-1"></div>
		<div class="col-sm-1"></div>
		<div class="col-sm-1">Contact us</div>
		<div class="col-sm-1">  Privacy & cookies</div>
		<div class="col-sm-1">  Terms of use</div>
		<div class="col-sm-1">  Trademarks</div>
		<div class="col-sm-1">  About our ads</div>
		<div class="col-sm-1">  © Microsoft 2018</div>
		
	</div>
		
</div>
</html>