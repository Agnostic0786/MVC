<!DOCTYPE html>
<html>

<head>
	 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">	
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body class="container-fluid" style="background-image: url('signin.jpg');">
	<div class="row" >
		<div class="col-sm-3"></div>
     	<div class="col-sm-6" style="text-align:center;margin-left:110px;height:370px;width:450px;margin-top: 150px;margin-bottom:150px;border:2px solid #DAEAF7 ;background-color: white ">
     		<form style="margin-left:;" action="/validate1" method="post">
                		<input type="hidden" name="_token" value="<?php echo csrf_token()?>"/>
     			<img src="microsoft.png" style=";margin-top: 10px;"/>
     			<h2> Sign In</h2>
     			<br>
     			<input type="text" placeholder="Email or Mobile" name="mobile" style="padding:0px 5px;height:40px;width:350px;border:0.5px solid #1230EC    ;border-radius: 1.5px"/	>
     			<br><br>
     			<input type="password" placeholder="Enter Password.." name="password" style="padding:0px 5px;margin-top:5px;height:40px;width:350px;border:0.5px solid #1230EC    ;border-radius: 1.5px"/	>
     			<br><br>
     			<input type="submit" value="SIGNIN" style="color:white;margin-top:5px;height:40px;width:350px;border:0.5px solid #1230EC    ;border-radius: 1.5px;background-color:  #1230EC "	>
     				</input>
     				<br>
     				<br>
     				<font><b>No account ?&nbsp;</b></font><a href="/sign2" style="text-decoration: none">Ceate One!</a>

     			
     		</form>
     		
     	</div>
		<div class="col-sm-3"></div>
	</div>
	</body>
</html>