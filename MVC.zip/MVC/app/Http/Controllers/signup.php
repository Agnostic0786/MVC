<?php

namespace App\Http\Controllers;

use DummyFullModelClass;
use App\lain;
use Illuminate\Http\Request;

class signup extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param  \App\lain  $lain
     * @return \Illuminate\Http\Response
     */
   /* public function index(lain $lain)
    {
        //
    }*/
         function requiredvalue($data , $empty="" , $pp1='',$pp2='')
    {
        $data=trim($data);
        $data = htmlspecialchars($data);
        $data = stripslashes($data);
        
        if($empty && strlen($data)=='')
        {
            die($empty);
        }
        return $data;
    }
         function  pp( $pp1,$pp2)
    {
        $flag=0;
        if($pp1=='' || $pp2==' ')
        {
            die("ENTER Password");
        }
        else if($pp1==$pp2)
        {
            $flag=1;
        }
        else
        {
            die("PASSWORD DO NOT MATCH");
        }
        return $flag;

    }
    
    
    public function register(Request $request)
    {
     $fname = self::requiredvalue($request->input('fname'),"Enter Your First name");
     $lname= self::requiredvalue($request->input('lname'),"Enter Your Last Name!!");
     $email = self::requiredvalue($request->input('email'),"Enter Your Email or mobile!!");
     $p1=($request->input('p1'));
     $p2 =($request->input('p2'));
     $f=self::pp($p1,$p2);
     if($fname!='' && $lname!='' && $email!='' && $f==1)
     {

        $message = "Correct Credentials But F..... OFFFFFF!!!!!";
        print( "<script type='text/javascript'>alert('Correct Credentials But F..... OFFFFFF!!!!!');</script>");
        sleep(5);
        return redirect('/home');
     }
    }
 
    /**
     * Show the form for creating a new resource.
     *
     * @param  \App\lain  $lain
     * @return \Illuminate\Http\Response
     */
    public function create(lain $lain)
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\lain  $lain
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, lain $lain)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\lain  $lain
     * @param  \DummyFullModelClass  $DummyModelVariable
     * @return \Illuminate\Http\Response
     */
    public function show(lain $lain, DummyModelClass $DummyModelVariable)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\lain  $lain
     * @param  \DummyFullModelClass  $DummyModelVariable
     * @return \Illuminate\Http\Response
     */
    public function edit(lain $lain, DummyModelClass $DummyModelVariable)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\lain  $lain
     * @param  \DummyFullModelClass  $DummyModelVariable
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, lain $lain, DummyModelClass $DummyModelVariable)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\lain  $lain
     * @param  \DummyFullModelClass  $DummyModelVariable
     * @return \Illuminate\Http\Response
     */
    public function destroy(lain $lain, DummyModelClass $DummyModelVariable)
    {
        //
    }
}
